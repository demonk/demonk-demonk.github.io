package cn.itrunner.ninepatchchange;

import java.io.InputStream;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.NinePatchDrawable;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;

public class NinePatchTest extends Activity {

    Button btn;
    ImageView imageView1, imageView2;


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.setContentView(R.layout.main);

        btn = (Button) findViewById(R.id.send);
        btn.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {
                try {
                    InputStream inputStream = NinePatchTest.this.getAssets().open("float_menu_right_xxh.9.png");
                    Rect out = new Rect();

                    Drawable drawable;
                    Bitmap bitmap = BitmapFactory.decodeStream(inputStream, out, null);

                    byte[] chunk = bitmap.getNinePatchChunk();

                    float width = bitmap.getWidth();
                    float newWidth = 90;
                    float scaleWidth = newWidth / width;

                    float height = bitmap.getHeight();
                    float newHeight = 100;
                    float scaleHeight = newHeight / height;

                    Matrix matrix = new Matrix();
                    matrix.postScale(scaleHeight, scaleWidth); //长和宽放大缩小的比例

                    Bitmap resizeBmp = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);

                    int xdivs = chunk[1];
                    int ydivs = chunk[2];

                    int start = 32;//从32个字节后是.9的真正信息
                    int index = 0;

                    //缩放X
                    for (int i = 0; i < xdivs; i++) {
                        int value = chunk[start + index];
                        chunk[start + index] = (byte) (value * scaleWidth);
                        index += 4;
                    }

                    //缩放Y
                    for (int i = 0; i < ydivs; i++) {
                        int value = chunk[start + index];
                        chunk[start + index] = (byte) (value * scaleHeight);
                        index += 4;
                    }


                    if (chunk == null) {
                        //普通图片
                        drawable = new BitmapDrawable(bitmap);
                    } else {
                        //.9图片
                        drawable = new NinePatchDrawable(NinePatchTest.this.getResources(), resizeBmp, chunk, out, null);
                    }

                    imageView2.setBackgroundDrawable(drawable);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

        });

        imageView1 = (ImageView) findViewById(R.id.imageView1);
        try {
            InputStream inputStream = NinePatchTest.this.getAssets().open("float_menu_right_xxh.9.png");
            Rect out = new Rect();

            Drawable drawable;
            Bitmap bitmap = BitmapFactory.decodeStream(inputStream, out, null);

            byte[] chunk = bitmap.getNinePatchChunk();
            drawable = new NinePatchDrawable(NinePatchTest.this.getResources(), bitmap, chunk, out, null);
            imageView1.setBackgroundDrawable(drawable);
        } catch (Exception e) {
            e.printStackTrace();
        }

        imageView2 = (ImageView) findViewById(R.id.imageView2);
    }
}
