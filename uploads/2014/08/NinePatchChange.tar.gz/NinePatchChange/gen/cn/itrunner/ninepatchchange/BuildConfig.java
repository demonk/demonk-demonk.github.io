/** Automatically generated file. DO NOT MODIFY */
package cn.itrunner.ninepatchchange;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}