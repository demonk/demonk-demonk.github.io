These scripts WILL modify your head unit. Plan accordingly. 

Usage:
OneClickInstall.(bat)(sh) HeadUnitIP My.apk

Important:
Please rename APKs to be installed to remove any spaces or crazy characters. This will not impact the final appearance of the app on the head unit, so keeping it short is preferred. These scripts will fail if this is not accomplished and results may vary. Something like "Waze.apk" is perfect, names like "My crazy APK Is @Wsome! v2.28.apk" will not work. 

These scripts will root the head unit if it's not already. 

Many thanks to purespin on XDA for figuring out the signature check mechanism!