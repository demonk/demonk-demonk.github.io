#!/system/bin/sh
/data/local/tmp/rootme/nefarious.sh
reboot
