package cn.itrunner.proxyTest;

public class HelloImpl implements Hello {

    @Override
    public void sayHello(String to) {
        System.out.println("say hello: " + to);
    }

    @Override
    public void print(String p) {
        System.out.println("print: " + p);
    }

}
