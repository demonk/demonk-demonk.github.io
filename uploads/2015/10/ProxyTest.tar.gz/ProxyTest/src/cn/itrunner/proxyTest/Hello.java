package cn.itrunner.proxyTest;

public interface Hello {

    void sayHello(String to);

    void print(String p);

}
