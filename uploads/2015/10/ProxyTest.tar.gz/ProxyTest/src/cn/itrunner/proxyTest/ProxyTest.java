package cn.itrunner.proxyTest;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

public class ProxyTest {

    private static final Class<?>[] constructorParams = { InvocationHandler.class };

    public static void main(String[] args) {
        HelloImpl impl = new HelloImpl();
        LogHandler handler = new LogHandler(impl);


        System.out.println(impl.getClass().getClassLoader().toString());
        Class<?>[] a = impl.getClass().getInterfaces();
        for (Class b : a)
            System.out.println(b.toString());

        try {
            Class<?> inter = Class.forName(impl.getClass().getInterfaces()[0].getName(), false, impl.getClass().getClassLoader());
            //            Class<?> inter = impl.getClass().getClassLoader().loadClass(impl.getClass().getInterfaces()[0].getName());

            Method getProxyClassMethod = Proxy.class.getDeclaredMethod("getProxyClass0", new Class[] { ClassLoader.class, Class[].class });
            getProxyClassMethod.setAccessible(true);
            Class<?> inter1 = (Class<?>) getProxyClassMethod.invoke(null, new Object[] { impl.getClass().getClassLoader(), impl.getClass().getInterfaces() });


            Constructor<?> cons = inter1.getConstructor(constructorParams);

            Hello aaaa = (Hello) cons.newInstance(new Object[] { handler });
            aaaa.print("I am Print");
            aaaa.sayHello("Demonk");

            Object hello = Proxy.newProxyInstance(impl.getClass().getClassLoader(), impl.getClass().getInterfaces(), handler);
            Class<?>[] hgg = hello.getClass().getInterfaces();
            for (Class hg : hgg)
                System.out.println("aaaa="+hg.toString());

            //
            //            hello.print("I am print");
            //            hello.sayHello("Demonk");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
