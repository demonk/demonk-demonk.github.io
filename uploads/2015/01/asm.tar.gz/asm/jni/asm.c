
int main(int argc, char** argv) {    
     __asm("LDR R7, [R4,#0x14]\n\t"
	"ldr r3,=10013\n\t"
	"CMP R7, R3\n\t"
	"pop {r0-r7}\n\t"
	"BEQ loc_ret_1\n\t"
	"LDR R3, [R0]\n\t"
	"LDR R2, [R4]\n\t"
	"pop {r1,pc}\n\t"
	"loc_ret_1:\n\t"
	"mov r3, #0\n\t"
	"mov r2, #1\n\t"
	"pop {r1,pc}");
    return 0;  
}    
