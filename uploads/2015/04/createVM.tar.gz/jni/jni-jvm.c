#include <jni.h>
#include <string.h>
#include <stdio.h>
#include <android/log.h>
#include <dlfcn.h>
#define LOGV(...) __android_log_print(ANDROID_LOG_VERBOSE, "jvm_test", __VA_ARGS__)
#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG , "jvm_test", __VA_ARGS__)
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO , "jvm_test", __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN , "jvm_test", __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR , "jvm_test", __VA_ARGS__)
#define PATH_SEPARATOR ':'

typedef int (*JNI_CreateJavaVM_Type)(JavaVM**,JNIEnv**,void*);

int main(void)
{
	JavaVMOption options[2];
	JNIEnv *env;
	JavaVM *jvm;
	JavaVMInitArgs vm_args;

	long status;
	jclass cls;
	jmethodID mid;
	jfieldID fid;
	jobject obj;

	options[0].optionString="-cp";
	options[1].optionString="hello.jar";
	memset(&vm_args,0,sizeof(vm_args));
	vm_args.version=JNI_VERSION_1_4;
	vm_args.nOptions=2;
	vm_args.ignoreUnrecognized=JNI_FALSE;
	vm_args.options=options;

	char buffer[1024];
	getcwd(buffer,1024);
	LOGV(buffer);

	//void *handle=dlopen("/system/lib/libart.so",RTLD_LAZY);//for ART
	void *handle=dlopen("/system/lib/libdvm.so",RTLD_LAZY);//for dalvik
	if(!handle)
	{
		LOGE("dlopen failed");
		return 0;
	}else{
		JNI_CreateJavaVM_Type JNI_CreateJavaVM_Func=(JNI_CreateJavaVM_Type)dlsym(handle,"JNI_CreateJavaVM");
		if(!JNI_CreateJavaVM_Func)
		{
			LOGE("create vm failed");
		}else{
			LOGV("create vm succ");
			if((status=JNI_CreateJavaVM_Func(&jvm,&env,&vm_args))<0)
			{
				LOGE("Dalvik VM init failed");
			}else{
				LOGV("Dalvik VM init succ");
				if(status!=JNI_ERR)
				{
					cls=(*env)->FindClass(env,"Hello");
					if(cls!=0)
					{
						LOGV("class found");
						mid=(*env)->GetStaticMethodID(env,cls,"test","([Ljava/lang/String;)Ljava/lang/String;");
						if(mid==0)
						{
							LOGE("method not found!");
						}else{
							const char* name="I am from JNI";
							jstring arg=(*env)->NewStringUTF(env,name);
							jstring result=(jstring)(*env)->CallStaticObjectMethod(env,cls,mid,arg);
							const char* str=(*env)->GetStringUTFChars(env,result,0);
							printf("getResult=%s\n",str);
							(*env)->ReleaseStringUTFChars(env,str,0);
						}
					}else{
						LOGE("class not found");
					}
				}
			}
		}
		dlclose(handle);
	}
}
