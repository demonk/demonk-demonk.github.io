
import java.lang.String;

public class Hello{
		public static void main(String[] args)
		{
				for(int i=0;i<args.length;i++)
				{
						System.out.println(args[i]);
				}
				System.out.println("Hello World");
		}	

		public static String test(String[] args)
		{
				return "I am from Java";
		}
}
