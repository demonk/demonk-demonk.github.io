package cn.demonk.agent;

import java.lang.instrument.Instrumentation;

public class TestAgent {

    public static void premain(String agentArgs, Instrumentation inst) {
        inst.addTransformer(new TestTransformer());
    }
}
