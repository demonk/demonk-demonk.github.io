package cn.demonk.agent;

import java.lang.instrument.ClassFileTransformer;
import java.lang.instrument.IllegalClassFormatException;
import java.security.ProtectionDomain;

import javassist.ClassPool;
import javassist.CtClass;
import javassist.CtMethod;
import javassist.CtNewMethod;

public class TestTransformer implements ClassFileTransformer {

    @Override
    public byte[] transform(ClassLoader loader, String className, Class<?> classBeingRedefined, ProtectionDomain protectionDomain, byte[] classfileBuffer) throws IllegalClassFormatException {

        if (className.equals("cn/demonk/agent/Hello")) {
            className = className.replace("/", ".");
            CtClass ctclass = null;

            //使用javassist获取className，需要注意javassist要找得到，为了方便我是直接集成进来了
            try {
                ctclass = ClassPool.getDefault().get(className);
                CtMethod[] methods = ctclass.getMethods();

                for (CtMethod method : methods) {
                    String methodName = method.getName();
                    if (!methodName.startsWith("hello_")) {
                        continue;
                    }

                    String newMethodName = methodName + "$a";//新建一个方法名,用于接纳旧方法
                    method.setName(newMethodName);//修改原来方法的名字 

                    //从原来方法中复制一个新方法
                    CtMethod newMethod = CtNewMethod.copy(method, methodName, ctclass, null);

                    StringBuilder sb = new StringBuilder();
                    sb.append("{");
                    //定义一个开始时间 
                    sb.append("\nlong startTime = System.currentTimeMillis();\n");
                    //调用newMethodName方法，由于newMethodName已经赋于原来的method了，这里意思即为调用原方法内容 
                    sb.append(newMethodName + "($$);\n");
                    //定义一个结束时间
                    sb.append("\nlong endTime = System.currentTimeMillis();\n");
                    //输出相差时间
                    sb.append("\nSystem.out.println(\"method " + methodName + " cost:\" +(endTime - startTime) +\"ms.\");");
                    sb.append("}");

                    //将以上定义的方法内容设置到方法对象中去,替换掉原来的方法内容
                    newMethod.setBody(sb.toString());
                    //将新增的方法添加到类中，名字与原来一样（原来的已经修改为method$a)
                    ctclass.addMethod(newMethod);
                }

                return ctclass.toBytecode();
            } catch (Exception e) {
                e.printStackTrace();
                System.err.println(e.getMessage());
            }
        }
        return null;
    }

}
