package cn.demonk.agent;

import java.util.List;

import com.sun.tools.attach.VirtualMachine;
import com.sun.tools.attach.VirtualMachineDescriptor;

public class AttachMain {

    public static void main(String[] args) {
        new AttachThread(args[0], args[1]).start();
    }

    private static class AttachThread extends Thread {

        private String mJarPath;
        private String mPid;

        public AttachThread(String path, String pid) {
            this.mJarPath = path;
            this.mPid = pid;
        }

        public void run() {
            VirtualMachine vm = null;
            List<VirtualMachineDescriptor> list = null;

            try {
                //获取当前系统内正在运行的vm列表，可以通过jps获取
                list = VirtualMachine.list();
                for (VirtualMachineDescriptor vmd : list) {
                    if (this.mPid.equals(vmd.id())) {
                        //通过pid找到要替换在vm,然后attach上去
                        vm = VirtualMachine.attach(vmd);
                        System.out.println("has attached to pid " + this.mPid);
                        break;
                    }

                }
                //开始load对应jar上指定的Agent，来实现动态加载类
                vm.loadAgent(this.mJarPath);
                //执行完就可以detach了
                vm.detach();
            } catch (Exception e) {
                System.err.println(e.getMessage());
            }
        }
    }
}
