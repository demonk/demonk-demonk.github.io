package cn.demonk.agent;

public class Main {

    public static void main(String[] args) throws InterruptedException {
        while (true) {
            TestClass.printMsg();
            Thread.sleep(1000);
        }
    }
}
