package cn.demonk.agent;

public class TestClass {

    public static void printMsg() {
        System.out.println("I'm from testClass_1");
    }
}
