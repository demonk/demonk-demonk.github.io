package cn.demonk.agent;

import java.lang.instrument.Instrumentation;
import java.lang.instrument.UnmodifiableClassException;

public class TestAgent {

    //当类需要加载时，JVM会调用agentmain这个方法
    //需要在manifest.mf中声明这个类
    public static void agentmain(String agentArgs, Instrumentation inst) throws UnmodifiableClassException {
        //注册一个转换器
        inst.addTransformer(new TestTransformer(), true);
        inst.retransformClasses(TestClass.class);
    }
}
