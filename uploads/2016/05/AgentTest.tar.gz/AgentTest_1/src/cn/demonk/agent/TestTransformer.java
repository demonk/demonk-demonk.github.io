package cn.demonk.agent;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.lang.instrument.ClassFileTransformer;
import java.lang.instrument.IllegalClassFormatException;
import java.security.ProtectionDomain;

public class TestTransformer implements ClassFileTransformer {

    @Override
    public byte[] transform(ClassLoader loader, String className, Class<?> classBeingRedefined, ProtectionDomain protectionDomain, byte[] classfileBuffer) throws IllegalClassFormatException {
        className = className.replace('/', '.');

        String classNameSimple = className.substring(className.lastIndexOf('.') + 1);
        if (!classNameSimple.equals("TestClass")) {
            return null;
        }

        String newClassFile = "/home/ligs/Desktop/cn/demonk/agent/" + classNameSimple + ".class";

        return getBytesFromClass(newClassFile);
    }

    private byte[] getBytesFromClass(String fileName) {
        File file = new File(fileName);
        long length = file.length();
        try (InputStream is = new FileInputStream(file)) {
            byte[] bytes = new byte[(int) length];

            int offset = 0;
            int numRead = 0;
            while (offset < bytes.length && (numRead = is.read(bytes, offset, bytes.length - offset)) >= 0) {
                offset += numRead;
            }

            if (offset < bytes.length) {
                throw new Exception("Could not completely read file " + file.getName());
            }
            is.close();
            return bytes;
        } catch (Exception e) {
            System.out.println("error occurs in _ClassTransformer!" + e.getClass().getName());
            return null;
        }
    }

}
