package cn.demonk.agent;

public class Hello {
    public static void hello_1() throws InterruptedException {
        System.out.println("hello world");
        Thread.sleep(500);
    }

    public static void hello_2(String name) throws InterruptedException {
        System.out.println("hello " + name);
        Thread.sleep(500);
    }
}
