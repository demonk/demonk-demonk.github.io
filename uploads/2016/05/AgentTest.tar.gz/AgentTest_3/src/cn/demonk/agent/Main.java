package cn.demonk.agent;

public class Main {

    public static void main(String[] args) {
        try {
            Hello.hello_1();
            Hello.hello_2("demonk");
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }
}
